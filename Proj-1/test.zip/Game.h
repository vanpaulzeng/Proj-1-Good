//
//  Game.h
//  Proj-1
//
//  Created by Admin on 2024-06-25.
//

#ifndef Game_h
#define Game_h

#include <stdio.h>
#include "Arena.h"


class Arena;

class Game
{
  public:
        // Constructor/destructor
    Game(int rows, int cols, int nRobots);
    ~Game();

    // Mutators
    void play();

  private:
    Arena* m_arena;
    // aaa This is really import to add, bcz the Game will abot to handle the Previous instance by using the pointer p_pMetrix
    Previous* p_pMetrix;
    Previous* m_Previous;
    
};

#endif /* Game_h */
