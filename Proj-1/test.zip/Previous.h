//
//  Previous.h
//  Proj-1
//
//  Created by Admin on 2024-06-29.
//

#ifndef Previous_h
#define Previous_h

#include "globals.h"

class Player;
class Arena;

class Previous
     { public:
         Previous(int nRows, int nCols);
         //~Previous();
         
         bool dropACrumb(int r, int c);
         void showPreviousMoves() const;
         void Display(int nRows, int cCols);



     private:
         char p_Grid[MAXROWS][MAXCOLS];
         int p_Rows, p_Cols;
         //add cross reference point in private define for each other
         //Player* p_Player;
         //Arena* p_Arena;
         //after up define, we can start to refer Player's values
};


#endif /* Previous_h */
